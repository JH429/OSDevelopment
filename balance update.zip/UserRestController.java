package fundsite.fund_web_backend.controller;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import fundsite.fund_web_backend.service.UserService;

@RestController
@RequestMapping("/user")
public class UserRestController {

    private final UserService userService;

    public UserRestController(UserService userService) {
        this.userService = userService;
    }

    @PutMapping("/add-balance-by-username")
    	public String addBalanceByUsername(@RequestParam(value="username")  String username, @RequestParam(value="amount") Double amount) {
    	
        userService.addBalanceByUsername(username, amount);
        return "Balance successfully updated for user with username: " + username;
    }
}
